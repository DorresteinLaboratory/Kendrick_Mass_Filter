
library(Rgraphviz)

source("kendrick.mass.filter_new_all_datamatrix_terminologyupdate.R")

ft <- "all17K/tab17plasmaspikedswab.csv"

pollist <- composition.analysis(
    mass_defect_parameter = 0.01, 
    retention_time = 0.8, 
    connection_filter = TRUE, 
    connections_min_number = 5,
    polymer=c('alkane_other_CH2',
              'oxidation',
              'water_cluster',
              'alkane_C2H4',
              'methanol_cluster',
              'acetonitrile_cluster',
              'propylation_other_C3H6',
              'polyethylene_glycol_other_C2H4O1',
              'perfluoro_CF2',
              'ammoniumchloride_cluster',
              'butylation_other_C4H8',
              'sodiumchloride_cluster',
              'polypropylene_glycol_other_C3H6O1',
              'ammoniumformate_cluster',
              'potassiumchloride_cluster',
              'polysiloxane',
              'sodiumacetate_cluster'),
    feature_matrix = ft, sprint=TRUE)

pollist$data$polyethylene_glycol_other_C2H4O1

poltab <- do.call(rbind, pollist$summary)
head(poltab)

poltab2 <- poltab[,c('p', 'features_before_filtering', 'features_after_filtering', 'features_after_filtering_wgraph')]
poltab2$N_filtered <-  poltab[,'features_before_filtering']- poltab[,'features_after_filtering']
poltab2$N_filtered_wg <-  poltab[,'features_before_filtering']- poltab[,'features_after_filtering_wgraph']
head(poltab2)

poltab3 <- do.call(rbind, apply(poltab2, 1, function(x) data.frame(Names=as.character(x['p']), class=c('wog', 'wg'), 
                                         value=as.numeric(matrix(x[c('N_filtered', 'N_filtered_wg')], nrow=2)))
                         )
          )
head(poltab3)

poltab3

characteristic <- c(
    "composition",
    "composition",
    "composition",
    "composition",
    "source",
    "source",
    "composition",
    "composition",
    "source",
    "source",
    "source",
    "source",
    "composition",
    "composition",
    "containment",
    "containment",
    "containment",
    "containment",
    "source",
    "source",
    "composition",
    "composition",
    "source",
    "source",
    "containment",
    "containment",
    "source",
    "source",
    "source",
    "source",
    "containment",
    "containment",
    "source",
    "source"
    )
poltab3 <- cbind(poltab3,characteristic)
head(poltab3)

write.csv(poltab3,"20180611_Output_Table_CompositionAnalysis.csv", row.names=FALSE)

poltab3 <- read.csv("20180611_Output_Table_CompositionAnalysis.csv", header=TRUE)

composition_plot <- ggplot(subset(poltab3,poltab3$class=="wg"),
                           aes(x=reorder(Names, -as.numeric(characteristic)), y=value))+
    geom_bar(aes(fill=characteristic), alpha =0.6, stat = "identity", width= 0.75, position="dodge")+
    scale_y_continuous(breaks=seq(0,500,50))+
    #facet_grid(~characteristic)+
    theme_minimal()+
            theme(
                panel.grid.major=element_line(colour ="grey95",size=0.5, linetype="blank"),
                panel.grid.minor=element_line(colour ="grey95",size=0.5, linetype="blank"),
                panel.border = element_rect(colour = "black", fill=NA, size=0.5),

                  axis.ticks=element_line(colour ="black",size=0.5, linetype="solid"),
                  axis.text=element_text(size=8),
                  axis.text.x=element_text(angle=0, hjust=0.5, vjust=0),
                  axis.line=element_line(colour="black",size=0.5, linetype="solid"),                  
                  axis.ticks.y=element_line(colour="black",size=0.5,linetype="solid"),
                  strip.text.y=element_text(size=8),
                  strip.text.x=element_text(size=8),
                  axis.title=element_text(size=8)) +
    theme(aspect.ratio=1)
composition_plot <- composition_plot + coord_fixed(ratio=1) + labs(x=NULL, y="MS1 Features Meet Criteria") +
    theme(legend.position="bottom", legend.title=element_blank()) + coord_flip() + 
    geom_text(aes(label=value),size=2, position = position_stack(0.5))

print(composition_plot)
ggsave("20180611_KMF_Figure_CompositionalPlot_17plasmaspikedswab.pdf",composition_plot, scale=1.5)
